﻿Eksyura Blog - Android app v1.0
===============================

Install this app and it gives you one button that opens the blog:
https://eksyurablog-304431n.maozi.io/

Contents : eksyura-blog-v1.0.apk
Platform : Android 5.0 (API 21) and newer
Package  : com.eksyura.blog

SHA256 (eksyura-blog-v1.0.apk)
3A7E9FC9FB3DA24E59B9381C9803E4899395BACA11E00D1672322D0D3276E9BD

How to install
--------------
1. Extract the .apk from this .zip and copy it to your phone
   (or download it directly on the phone).
2. Tap the .apk file. Android will ask you to allow installing from
   this source - tap "Settings" / "Allow" and turn it on, then go back
   and tap "Install".
3. If Play Protect shows a warning, tap "Install anyway".
   This is normal for any app that is not distributed through Google
   Play; it does not mean the file is harmful.

The app only requests the INTERNET permission, contains no ads, no
analytics and no background services. It simply opens your browser.

You can check the file was not altered with:

  certutil -hashfile eksyura-blog-v1.0.apk SHA256

Source: https://eksyura.github.io/Blog/
