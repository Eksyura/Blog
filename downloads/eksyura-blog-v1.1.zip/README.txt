Eksyura Blog - Android app v1.1
=====================================

Install this app and it gives you one button that opens the blog:
https://eksyurablog-304431n.maozi.io/

Contents : eksyura-blog-v1.1.apk
Platform : Android 5.0 (API 21) and newer
Package  : com.eksyura.blog
Version  : 1.1 (versionCode 2)

SHA256 (eksyura-blog-v1.1.apk)
38C35000A1C78AD7A33E7BB8F9A495CEBDDEC4637F65F2A94B8953DBBCAAC3FC

What's new in 1.1
-----------------------
- The background artwork is blurred more heavily, so the wordmark and the
  button stand out better.
- Everything is still Cascadia Code, with the wordmark on the upper third
  line and the button on the lower third line.

How to install
--------------
1. Extract the .apk from this .zip and copy it to your phone
   (or download it directly on the phone).
2. Tap the .apk file. Android will ask you to allow installing from
   this source - tap "Settings" / "Allow" and turn it on, then go back
   and tap "Install".
3. If Play Protect shows a warning, tap "Install anyway".
   This is normal for any app that is not distributed through Google
   Play; it does not mean the file is harmful.
4. If a previous version is installed, Android will offer to update it
   instead. The signing key is unchanged, so updating is safe and keeps
   your existing install.

The app only requests the INTERNET permission, contains no ads, no
analytics and no background services. It simply opens your browser.

You can check the file was not altered with:

  certutil -hashfile eksyura-blog-v1.1.apk SHA256

Source: https://eksyura.github.io/Blog/
